package com.example.myapplication2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


public class ProductAdditionActivity extends ProductBaseActivity {

   // Button save_prd;
    private EditText prdName;

    private EditText prdPrice;
    private EditText prdPrice2;
    private EditText prdPrice3;
    private EditText prdPrice4;
    private EditText prdPrice5;


    private EditText prdStore;
    private EditText prdStore2;
    private EditText prdStore3;
    private EditText prdStore4;
    private EditText prdStore5;


    private EditText prdLocation;
    private EditText prdLocation2;
    private EditText prdLocation3;
    private EditText prdLocation4;
    private EditText prdLocation5;

   // final Map<String, Object> map = new HashMap<>();
   // private DocumentReference documentReference= firestoreDB.collection("products").document("1");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.product_addition);
        super.onCreate(savedInstanceState);


        prdName = findViewById(R.id.product_name);

        prdPrice = findViewById(R.id.product_price);
        prdPrice2= findViewById(R.id.product_price2);
        prdPrice3= findViewById(R.id.product_price3);
        prdPrice4= findViewById(R.id.product_price4);
        prdPrice5= findViewById(R.id.product_price5);

        // save_prd = findViewById(R.id.save_prd);

        prdStore= findViewById(R.id.product_store);
        prdStore2= findViewById(R.id.product_store2);
        prdStore3= findViewById(R.id.product_store3);
        prdStore4= findViewById(R.id.product_store4);
        prdStore5= findViewById(R.id.product_store5);


        prdLocation= findViewById(R.id.product_location);
        prdLocation2= findViewById(R.id.product_location2);
        prdLocation3= findViewById(R.id.product_location3);
        prdLocation4= findViewById(R.id.product_location4);
        prdLocation5= findViewById(R.id.product_location5);



    }



    public void saveProduct(View v) {
        addProductToDb(createProductObj());

    }

    private Product createProductObj(){
        final Product product = new Product();
        product.setProdId((String)barcodeValue.getText());
        product.setProdName(prdName.getText().toString());

        product.setProdStore(prdStore.getText().toString());
        product.setProdStore2(prdStore2.getText().toString());
        product.setProdStore3(prdStore3.getText().toString());
        product.setProdStore4(prdStore4.getText().toString());
        product.setProdStore5(prdStore5.getText().toString());

        product.setProdLocation(prdLocation.getText().toString());
        product.setProdLocation2(prdLocation2.getText().toString());
        product.setProdLocation3(prdLocation3.getText().toString());
        product.setProdLocation4(prdLocation4.getText().toString());
        product.setProdLocation5(prdLocation5.getText().toString());


        /*float price = Float.valueOf(prdPrice.getText().toString());*/ /*float price = Float.parseFloat(prdPrice.getText().toString());*/
       // product.setPrice(price);
        product.setPrice(prdPrice.getText().toString());
        product.setPrice2(prdPrice2.getText().toString());
        product.setPrice3(prdPrice3.getText().toString());
        product.setPrice4(prdPrice4.getText().toString());
        product.setPrice5(prdPrice5.getText().toString());


       //final Map<String, Object> map = new HashMap<>();

        /*map.put("name", prdName);
        map.put("price", prdPrice);
        map.put("BarcodeNumber", barcodeValue);*/
        return product;
    }


   /* private void addProductToDb(Product productObj){*/ private void addProductToDb(Product product){
        /*FirebaseFirestore*/ firestoreDB= FirebaseFirestore.getInstance();

       /* documentReference.set(product).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                refreshUi();
                Toast.makeText(ProductAdditionActivity.this,
                        "Product has been added to db",
                        Toast.LENGTH_SHORT).show();

            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Toast.makeText(ProductAdditionActivity.this,
                                "Product could not be added to db, try again",
                                Toast.LENGTH_SHORT).show();

                    }
                });*/

             firestoreDB.collection("products")
               .add(product)
               //.add(map)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {



                        refreshUi();
                        //Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());


                        Toast.makeText(ProductAdditionActivity.this,
                                "Product has been added to database.",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(ProductAdditionActivity.this,
                                "Product could not be added to database. Please try again",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }
    /*public void saveProduct(View v) {
        addProductToDb(createProductObj());
    }*/


    private void refreshUi(){

        prdName.setText("");
        barcodeImage.setImageBitmap(null);
        barcodeValue.setText("");

        prdPrice.setText("");
        prdPrice2.setText("");
        prdPrice3.setText("");
        prdPrice4.setText("");
        prdPrice5.setText("");

        prdStore.setText("");
        prdStore2.setText("");
        prdStore3.setText("");
        prdStore4.setText("");
        prdStore5.setText("");

        prdLocation.setText("");
        prdLocation2.setText("");
        prdLocation3.setText("");
        prdLocation4.setText("");
        prdLocation5.setText("");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_BARCODE && resultCode == RESULT_OK) {
            File imgFile = new File(barcodeFilePath);
            if (imgFile.exists()) {
                barcodeImage.setImageURI(Uri.fromFile(imgFile));
                Bitmap bitmap = null;
                try {
                    bitmap = ProductUtil.getUprightImage(barcodeFilePath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ProductUtil.setBarcodeValue(bitmap, barcodeValue);
            }
        }
    }
}