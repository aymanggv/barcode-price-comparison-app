package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;



public class MainActivity extends AppCompatActivity {

    /*private static int SPLASH_TIME_OUT=3000;*/


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent homeIntent= new Intent(MainActivity.this, MainActivity.class);
                        startActivity(homeIntent);
                        finish();
            }
        }, SPLASH_TIME_OUT);

*/
    }

    public void addProduct(View v){
        Intent intent1 = new Intent(this, ProductAdditionActivity.class);
        startActivity(intent1);
    }

    public void getProduct(View v){
        Intent intent2 = new Intent(this, ProductReaderActivity.class);
        startActivity(intent2);
    }

    public void getDetails(View v){
        Intent intent3 = new Intent(this, ProductDetails.class);
        startActivity(intent3);
    }


}
