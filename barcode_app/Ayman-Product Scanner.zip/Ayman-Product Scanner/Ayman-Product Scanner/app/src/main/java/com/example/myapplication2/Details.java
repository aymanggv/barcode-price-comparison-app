package com.example.myapplication2;

public class Details {

    private String ProdDetails;
    private String ProdName;
   // private String ProdId;

    public Details() {}


    public Details (String ProdDetails, String ProdName) {
        this.ProdDetails =ProdDetails;
        this.ProdName=ProdName;
    }

    public String getProdDetails() {
        return ProdDetails;
    }

    public void setProdDetails(String ProdDetails) {
        this.ProdDetails = ProdDetails;
    }


    public String getProdName() {
        return ProdName;

    }

    public void setProdName(String ProdName) {
        this.ProdName = ProdName;
    }
}
