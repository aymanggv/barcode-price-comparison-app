package com.example.myapplication2;

public class Product {

    private String ProdName;
    private String ProdId;

    private String price;
    private String price2;
    private String price3;
    private String price4;
    private String price5;


    private String ProdStore;
    private String ProdStore2;
    private String ProdStore3;
    private String ProdStore4;
    private String ProdStore5;


    private String ProdLocation;
    private String ProdLocation2;
    private String ProdLocation3;
    private String ProdLocation4;
    private String ProdLocation5;





    // private Bitmap bitmap;


    public Product() {}



    public Product(String ProdName, String ProdId, String price, String ProdStore, String ProdLocation, String price2, String price3,
                  String price4, String price5, String ProdStore2, String ProdStore3, String ProdStore4, String ProdStore5,
                   String ProdLocation2, String ProdLocation3, String ProdLocation4, String ProdLocation5 ){
        this.ProdName=ProdName;
        this.ProdId=ProdId;

        this.price=price;
        this.price2=price2;
        this.price3=price3;
        this.price3=price4;
        this.price3=price5;


        this.ProdStore= ProdStore;
        this.ProdStore2=ProdStore2;
        this.ProdStore3=ProdStore3;
        this.ProdStore3=ProdStore4;
        this.ProdStore3=ProdStore5;


        this.ProdLocation=ProdLocation;
        this.ProdLocation2=ProdLocation2;
        this.ProdLocation3=ProdLocation3;
        this.ProdLocation3=ProdLocation4;
        this.ProdLocation3=ProdLocation5;


    }

    public String getPrice2() {
        return price2;
    }

    public void setPrice2(String price2) {
        this.price2 = price2;
    }

    public void setPrice3(String price3) {
        this.price3 = price3;
    }

    public String getPrice3() {
        return price3;
    }

    public void setPrice4(String price4) {
        this.price4 = price4;
    }

    public String getPrice4() {
        return price4;
    }

    public void setPrice5(String price5) {
        this.price5 = price5;
    }

    public String getPrice5() {
        return price5;
    }




    public String getProdLocation() {
        return ProdLocation;
    }

    public void setProdLocation(String ProdLocation) {
        this.ProdLocation = ProdLocation;
    }

    public String getProdLocation2() {
        return ProdLocation2;
    }

    public void setProdLocation2(String ProdLocation2) {
        this.ProdLocation2 = ProdLocation2;
    }

    public String getProdLocation3() {
        return ProdLocation3;
    }

    public void setProdLocation3(String ProdLocation3) {
        this.ProdLocation3 = ProdLocation3;
    }

    public String getProdLocation4() {
        return ProdLocation4;
    }

    public void setProdLocation4(String ProdLocation4) {
        this.ProdLocation4 = ProdLocation4;
    }

    public String getProdLocation5() {
        return ProdLocation5;
    }

    public void setProdLocation5(String ProdLocation5) {
        this.ProdLocation5 = ProdLocation5;
    }




    public String getProdStore() {
        return ProdStore;
    }

    public void setProdStore(String ProdStore) {
        this.ProdStore = ProdStore;
    }

    /*public void setProdStore(String prodStore) {
        this.ProdStore = prodStore;
    }*/


    public String getProdStore2() {
        return ProdStore2;
    }

    public void setProdStore2(String ProdStore2) {
        this.ProdStore2 = ProdStore2;
    }

    public String getProdStore3() {
        return ProdStore3;
    }

    public void setProdStore3(String ProdStore3) {
        this.ProdStore3 = ProdStore3;
    }

    public String getProdStore4() {
        return ProdStore4;
    }

    public void setProdStore4(String ProdStore4) {
        this.ProdStore4 = ProdStore4;
    }

    public String getProdStore5() {
        return ProdStore5;
    }

    public void setProdStore5(String ProdStore5) {
        this.ProdStore5 = ProdStore5;
    }




    public String getPrice() {
            return price;
        }

/*
    public void setPrice(float price) {
        this.price = price;
    }
*/

    public void setPrice(String price) {
        this.price = price;
    }


        public String getProdId() {
            return ProdId;
        }

    public void setProdId(String ProdId) {
        this.ProdId = ProdId;
    }

        public String getProdName() {
            return ProdName;

        }

    public void setProdName(String ProdName) {
        this.ProdName = ProdName;
    }





   /* public void setBitmap(Bitmap bitmap){
        this.bitmap=bitmap;
    }
    public Bitmap getBitmap(){
        return this.bitmap;
    }*/

}