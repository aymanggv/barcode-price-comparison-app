package com.example.myapplication2;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcode;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;

public class ProductReaderActivity extends ProductBaseActivity {

   /* private TextView prdName;
    private TextView prdPrice;
    private TextView prdStore;
    private TextView prdLocation;
    private TextView prdPrice2;*/
    private TextView prdName;

    private TextView prdPrice;
    private TextView prdPrice2;
    private TextView prdPrice3;
    private TextView prdPrice4;
    private TextView prdPrice5;


    private TextView prdStore;
    private TextView prdStore2;
    private TextView prdStore3;
    private TextView prdStore4;
    private TextView prdStore5;


    private TextView prdLocation;
    private TextView prdLocation2;
    private TextView prdLocation3;
    private TextView prdLocation4;
    private TextView prdLocation5;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.product_reader);
        super.onCreate(savedInstanceState);

        prdName = findViewById(R.id.product_name);

        prdPrice = findViewById(R.id.product_price);
        prdPrice2=findViewById(R.id.product_price2);
        prdPrice3=findViewById(R.id.product_price3);
        prdPrice4=findViewById(R.id.product_price4);
        prdPrice5=findViewById(R.id.product_price5);


        prdStore= findViewById(R.id.product_store);
        prdStore2= findViewById(R.id.product_store2);
        prdStore3= findViewById(R.id.product_store3);
        prdStore4= findViewById(R.id.product_store4);
        prdStore5= findViewById(R.id.product_store5);

        prdLocation= findViewById(R.id.product_location);
      //  prdLocation.setMovementMethod(LinkMovementMethod.getInstance());
        prdLocation2= findViewById(R.id.product_location2);
        prdLocation3= findViewById(R.id.product_location3);
        prdLocation4= findViewById(R.id.product_location4);
        prdLocation5= findViewById(R.id.product_location5);

       /* btnDetails= findViewById(R.id.btn_details);

        btnDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(ProductReaderActivity.this, ProductDetails.class);
                startActivity(intent3);
            }
        });
*/


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_BARCODE && resultCode == RESULT_OK) {
            File imgFile = new File(barcodeFilePath);
            if (imgFile.exists()) {
                Bitmap bitmap = null;
                try {
                    bitmap = ProductUtil.getUprightImage(barcodeFilePath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Task<List<FirebaseVisionBarcode>> result =
                        ProductUtil.readBarcodeValueTask(bitmap);
                readProductFromDb(result);
            }
        }
    }



    private void getProductfromDB(String prodId) { /* private void getProduct(String prodId) {*//*private void getProduct(String ProdId) {*/
        firestoreDB.collection("products")
                .whereEqualTo("prodId", prodId)  /* .whereEqualTo("ProdId", ProdId)*/
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                displayProductDetails(document.toObject(Product.class));
                                break;
                            }
                        } else {
                            Toast.makeText(ProductReaderActivity.this,
                                    "Failed to get product data, please try again.",
                                    Toast.LENGTH_SHORT).show();
                            Log.d("get product",
                                    "Error getting documents: ", task.getException());
                        }
                    }
                });

    }

    private void displayProductDetails(Product product) {
        prdName.setText(product.getProdName());
        barcodeValue.setText(product.getProdId());

        prdPrice.setText(String.valueOf(product.getPrice()));
        prdPrice2.setText(String.valueOf(product.getPrice2()));
        prdPrice3.setText(String.valueOf(product.getPrice3()));
        prdPrice4.setText(String.valueOf(product.getPrice4()));
        prdPrice5.setText(String.valueOf(product.getPrice5()));

        prdStore.setText(product.getProdStore());
        prdStore2.setText(product.getProdStore2());
        prdStore3.setText(product.getProdStore3());
        prdStore4.setText(product.getProdStore4());
        prdStore5.setText(product.getProdStore5());

      //  prdLocation.setMovementMethod(LinkMovementMethod.getInstance());
        prdLocation.setText(product.getProdLocation());
        prdLocation2.setText(product.getProdLocation2());
        prdLocation3.setText(product.getProdLocation3());
        prdLocation4.setText(product.getProdLocation4());
        prdLocation5.setText(product.getProdLocation5());



    }



    private void readProductFromDb(Task<List<FirebaseVisionBarcode>> result) {
        result.addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionBarcode>>() {
            @Override
            public void onSuccess(List<FirebaseVisionBarcode> barcodes) {
                if(barcodes.size() == 0){
                    Toast.makeText(ProductReaderActivity.this,
                            "Can not read barcode. Please try again.",
                            Toast.LENGTH_SHORT).show();
                }
                for (FirebaseVisionBarcode barcode : barcodes) {
                    String rawValue = barcode.getRawValue();
                    getProductfromDB(rawValue);   /*getProduct(rawValue);*/
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(ProductReaderActivity.this,
                        "No bar-codes found. Please try again",
                        Toast.LENGTH_SHORT).show();
                Log.d("get product",
                        "Error reading barcode: "+ e.toString());
            }
        });
    }


}