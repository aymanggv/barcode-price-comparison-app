package com.example.myapplication2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcode;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class ProductDetails extends ProductBaseActivity {

    private TextView prdDetails;
    private TextView prdName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_details);

        prdName = findViewById(R.id.product_name);
        prdDetails = findViewById(R.id.product_info);

    }

    @Override
    protected void onActivityResult(int requestCode1, int resultCode1, Intent data1) {
        super.onActivityResult(requestCode1, resultCode1, data1);
        if (requestCode1 == REQUEST_BARCODE && resultCode1 == RESULT_OK) {
            File imgFile1 = new File(barcodeFilePath);
            if (imgFile1.exists()) {
                Bitmap bitmap1 = null;
                try {
                    bitmap1 = ProductUtil.getUprightImage(barcodeFilePath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Task<List<FirebaseVisionBarcode>> result1 =
                        ProductUtil.readBarcodeValueTask(bitmap1);
                readProductFromDb1(result1);
            }
        }
    }



    private void getProductDetails(String prodId) {       /* private void getProduct(String ProdId) {*/
        firestoreDB.collection("details")
                .whereEqualTo("prodId", prodId)  /* .whereEqualTo("ProdId", ProdId)*/
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                displayProductDetails(document.toObject(Details.class));

                                break;
                            }
                        } else {
                            Toast.makeText(ProductDetails.this,
                                    "Failed to get product data, please try again.",
                                    Toast.LENGTH_SHORT).show();
                            Log.d("get product",
                                    "Error getting documents: ", task.getException());
                        }
                    }
                });

    }


    private void displayProductDetails(Details details) {
        prdDetails.setText(details.getProdDetails());
        prdName.setText(details.getProdName());
    }

    private void readProductFromDb1(Task<List<FirebaseVisionBarcode>> result1) {
        result1.addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionBarcode>>() {
            @Override
            public void onSuccess(List<FirebaseVisionBarcode> barcodes1) {
                if(barcodes1.size() == 0){
                    Toast.makeText(ProductDetails.this,
                            "Can not read bar-code. Please try again.",
                            Toast.LENGTH_SHORT).show();
                }
                for (FirebaseVisionBarcode barcode1 : barcodes1) {
                    String rawValue1 = barcode1.getRawValue();
                    getProductDetails(rawValue1);   /*getProduct(rawValue);*/
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(ProductDetails.this,
                        "No bar-codes found. Please try again",
                        Toast.LENGTH_SHORT).show();
                Log.d("get product",
                        "Error reading bar-code: "+ e.toString());
            }
        });
    }

}
